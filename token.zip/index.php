<!DOCTYPE html>
<html>
<head>
    <title>Accueil</title>
</head>
<body>
    <h1>Bienvenue sur notre site Web</h1>
    <p>Vous êtes maintenant connecté.</p>
    <a href="profile.php">Accéder à votre profil</a>

    <script src="auth.js"></script>
</body>
</html>
